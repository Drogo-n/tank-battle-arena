// Declara o pacote do projeto
package gradle;

// Define a classe Bot
public class Bot {

}
