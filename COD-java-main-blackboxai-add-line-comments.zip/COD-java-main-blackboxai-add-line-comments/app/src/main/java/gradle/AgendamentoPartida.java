package gradle;

public class AgendamentoPartida {

}
