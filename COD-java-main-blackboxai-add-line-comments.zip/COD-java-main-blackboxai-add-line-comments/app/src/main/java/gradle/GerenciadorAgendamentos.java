package gradle;

public class GenrenciarPartidas {

}
