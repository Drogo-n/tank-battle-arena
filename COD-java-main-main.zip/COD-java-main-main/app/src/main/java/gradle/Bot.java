package gradle;

public class Bot {

}
