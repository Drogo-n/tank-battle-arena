# TODO: Convert Console App to JavaFX GUI

- [x] Update build.gradle to include JavaFX dependencies
- [x] Implement Pesado.java class
- [x] Modify Modos.java to remove Scanner and adapt for GUI
- [x] Refactor App.java to extend Application and create GUI
- [x] Test the JavaFX application
